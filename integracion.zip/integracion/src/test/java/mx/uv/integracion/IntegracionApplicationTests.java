package mx.uv.integracion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IntegracionApplicationTests {

	@Test
	void contextLoads() {
	}

}
